# PRUMIM AI

## Setup
1. Install Node.js 20+ and run `npm install`.
2. Add `GROQ_API_KEY` to your Vercel environment variables.
3. Deploy with `vercel` or run locally with `npm run dev`.

## Engine update
`engine.js` now orchestrates the existing Groq agent and streams activity events to the interface. The indicator updates during planning, tool execution, file reads/writes, verification, completion and errors.

## Terminal safety
The included `/api/terminal` endpoint remains deliberately disabled (HTTP 503). The agent can only use a separately configured, authenticated and sandboxed terminal service through `TERMINAL_API_URL` and `TERMINAL_API_TOKEN`. Do not expose an unrestricted shell endpoint publicly.


## Interface update
The chat interface now uses a restrained ChatGPT/Claude-inspired layout: no animated orb, no decorative floating status widget, and no glowing/karaoke-style activity effects. Activity appears inline only while PRUMIM is working. Terminal activity labels reflect actual engine events; terminal runtime still requires a separately configured secure runtime.
