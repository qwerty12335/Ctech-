import engine from "../engine.js";

const GROQ_API_KEY = process.env.GROQ_API_KEY;

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store, no-transform");
  if (req.method !== "POST") return res.status(405).json({ success: false, error: "Wrong method. Use POST." });
  if (!GROQ_API_KEY) return res.status(503).json({ success: false, error: "Groq API key is missing. Add GROQ_API_KEY in Vercel." });

  const { messages } = req.body || {};
  if (!Array.isArray(messages) || messages.length === 0) return res.status(400).json({ success: false, error: "Messages are required." });

  // Stream activity events so the UI can display live Claude-style execution states.
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders?.();
  const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

  try {
    const result = await engine.run({
      messages,
      apiKey: GROQ_API_KEY,
      onActivity: (activity) => send("activity", activity)
    });
    send("result", {
      success: true,
      assistant: "PRUMIM",
      model: result.model,
      reply: result.reply,
      activities: result.activities || [],
      status: result.status || null,
      task: result.task || null
    });
  } catch (error) {
    console.error("PRUMIM chat error:", error.message);
    send("failure", { success: false, error: error.message || "AI service unavailable." });
  } finally {
    res.end();
  }
}
