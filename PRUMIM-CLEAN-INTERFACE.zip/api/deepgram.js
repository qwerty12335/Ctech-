/**
 * PRUMIM AI — DEEPGRAM TRANSCRIPTION API
 * Requires DEEPGRAM_API_KEY in Vercel environment variables.
 */
export const config = {
  api: { bodyParser: false }
};

async function readRawBody(req, maxBytes = 15 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new Error("Audio upload exceeds the 15 MB limit.");
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed." });
  }

  const apiKey = process.env.DEEPGRAM_API_KEY;
  if (!apiKey) {
    return res.status(503).json({ success: false, error: "Deepgram is not configured. Add DEEPGRAM_API_KEY in Vercel." });
  }

  try {
    const audio = await readRawBody(req);
    if (!audio.length) return res.status(400).json({ success: false, error: "No audio was received." });

    const contentType = String(req.headers["content-type"] || "audio/webm").split(";")[0];
    const allowedTypes = ["audio/webm", "audio/mp4", "audio/mpeg", "audio/wav", "audio/ogg", "audio/flac"];
    if (!allowedTypes.includes(contentType)) {
      return res.status(415).json({ success: false, error: "Unsupported audio format." });
    }

    const deepgramURL = "https://api.deepgram.com/v1/listen?model=nova-3&smart_format=true&punctuate=true";
    const upstream = await fetch(deepgramURL, {
      method: "POST",
      headers: {
        "Authorization": `Token ${apiKey}`,
        "Content-Type": contentType
      },
      body: audio,
      signal: AbortSignal.timeout(25000)
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("Deepgram request failed:", upstream.status, data.err_code || data.err_msg || "Unknown error");
      return res.status(502).json({ success: false, error: data.err_msg || "Deepgram transcription failed." });
    }

    const transcript = data.results?.channels?.[0]?.alternatives?.[0]?.transcript || "";
    return res.status(200).json({ success: true, transcript });
  } catch (error) {
    const status = error.message?.includes("15 MB") ? 413 : 500;
    console.error("PRUMIM Deepgram API error:", error.message);
    return res.status(status).json({ success: false, error: error.message || "Transcription service failed." });
  }
}
