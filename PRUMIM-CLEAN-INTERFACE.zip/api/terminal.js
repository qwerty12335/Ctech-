/**
 * PRUMIM AI — TERMINAL API
 *
 * Temporarily disabled for public deployment.
 * The previous implementation allowed unauthenticated command execution.
 * Re-enable only after adding strong authentication, authorization,
 * command/argument allowlisting, and filesystem sandboxing.
 */
export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    return res.status(405).json({
      success: false,
      error: "Method not allowed."
    });
  }

  return res.status(503).json({
    success: false,
    error: "Terminal access is disabled until secure authentication and sandboxing are configured."
  });
}
