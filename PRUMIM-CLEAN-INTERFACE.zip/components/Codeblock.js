/**
 * PRUMIM AI — CODE BLOCK RENDERER
 * Safely renders fenced code blocks and inline code.
 */
export function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);
}

export function renderMessage(value = "") {
  const source = String(value);
  const fenced = /```([\w.+#-]*)\s*\n?([\s\S]*?)```/g;
  let html = "";
  let cursor = 0;
  let match;

  while ((match = fenced.exec(source)) !== null) {
    const before = source.slice(cursor, match.index);
    if (before) html += `<span class="prumim-message-text">${escapeHTML(before).replace(/\n/g, "<br>")}</span>`;

    const language = escapeHTML(match[1] || "code");
    const code = match[2].replace(/\n$/, "");
    const escapedCode = escapeHTML(code);
    html += `
      <section class="prumim-codeblock">
        <header class="prumim-codeblock-head">
          <span>${language}</span>
          <button type="button" class="prumim-code-copy" data-copy-code="">Copy code</button>
        </header>
        <pre><code>${escapedCode}</code></pre>
      </section>`;
    cursor = fenced.lastIndex;
  }

  const remainder = source.slice(cursor);
  if (remainder) html += `<span class="prumim-message-text">${escapeHTML(remainder).replace(/\n/g, "<br>")}</span>`;
  return html || "";
}

const Codeblock = { renderMessage, escapeHTML };
export default Codeblock;
