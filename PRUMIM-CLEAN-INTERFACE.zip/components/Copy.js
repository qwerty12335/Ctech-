/** PRUMIM AI — COPY UTILITIES */
export async function copyText(value) {
  const text = String(value ?? "");
  if (!text) return false;

  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
    } else {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      const copied = document.execCommand("copy");
      area.remove();
      if (!copied) throw new Error("Clipboard copy was blocked.");
    }
    return true;
  } catch (error) {
    console.error("PRUMIM copy error:", error);
    return false;
  }
}

export function showCopyFeedback(button, message = "Copied") {
  if (!button) return;
  const previous = button.textContent;
  button.textContent = message;
  button.disabled = true;
  setTimeout(() => {
    button.textContent = previous || "Copy";
    button.disabled = false;
  }, 1200);
}

export default { copyText, showCopyFeedback };
