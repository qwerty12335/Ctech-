/**
 * PRUMIM AI — DEEPGRAM VOICE CLIENT
 * Records microphone audio and sends it to the server-side transcription route.
 */
export class PRUMIMDeepgram {
  constructor({ buttonId = "voiceBtn", endpoint = "/api/deepgram" } = {}) {
    this.button = document.getElementById(buttonId);
    this.endpoint = endpoint;
    this.recorder = null;
    this.stream = null;
    this.chunks = [];
    this.recording = false;
    this.originalLabel = this.button?.textContent || "Voice";
    this.button?.addEventListener("click", () => this.toggle().catch(error => this.fail(error)));
  }

  async toggle() {
    if (this.recording) return this.stop();
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
      throw new Error("Microphone recording is not supported in this browser.");
    }
    this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mime = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"]
      .find(type => MediaRecorder.isTypeSupported(type));
    this.recorder = new MediaRecorder(this.stream, mime ? { mimeType: mime } : undefined);
    this.chunks = [];
    this.recorder.addEventListener("dataavailable", event => {
      if (event.data?.size) this.chunks.push(event.data);
    });
    this.recorder.addEventListener("stop", () => this.transcribe().catch(error => this.fail(error)));
    this.recorder.start();
    this.recording = true;
    this.setLabel("Stop recording");
    this.setActivity("speaking", "Listening to your voice...");
  }

  stop() {
    if (this.recorder && this.recording) {
      this.recording = false;
      this.recorder.stop();
      this.stream?.getTracks().forEach(track => track.stop());
      this.setLabel("Transcribing...");
    }
  }

  async transcribe() {
    const blob = new Blob(this.chunks, { type: this.recorder?.mimeType || "audio/webm" });
    if (!blob.size) throw new Error("No audio was recorded.");
    const response = await fetch(this.endpoint, {
      method: "POST",
      headers: { "Content-Type": blob.type },
      body: blob
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.success) throw new Error(data.error || "Voice transcription failed.");
    window.dispatchEvent(new CustomEvent("prumim:transcript", { detail: { transcript: data.transcript } }));
    this.setActivity("completed", "Voice transcribed");
    this.setLabel(this.originalLabel);
  }

  fail(error) {
    this.stream?.getTracks().forEach(track => track.stop());
    this.recording = false;
    this.setLabel(this.originalLabel);
    this.setActivity("error", error.message || "Voice transcription failed");
    window.dispatchEvent(new CustomEvent("prumim:notice", { detail: { message: error.message || "Voice transcription failed." } }));
  }

  setLabel(label) {
    if (this.button) this.button.textContent = label;
  }

  setActivity(state, detail) {
    window.dispatchEvent(new CustomEvent("prumim:activity", { detail: { state, detail } }));
  }
}

export default PRUMIMDeepgram;
