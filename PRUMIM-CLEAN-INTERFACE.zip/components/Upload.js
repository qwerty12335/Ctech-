/**
 * PRUMIM AI — FILE UPLOAD CLIENT
 * Reads supported text files locally and attaches their contents to the next prompt.
 * Files are not persisted on the server by this component.
 */
const TEXT_TYPES = new Set([
  "text/plain", "text/markdown", "text/csv", "text/html", "text/css",
  "application/json", "application/javascript", "text/javascript",
  "application/xml"
]);
const TEXT_EXTENSIONS = /\.(txt|md|csv|json|js|mjs|cjs|ts|tsx|jsx|html|css|xml|yml|yaml|py|java|c|cpp|h|sql|sh|env\.example)$/i;

export class PRUMIMUpload {
  constructor({ buttonId = "uploadBtn", inputId = "fileInput", listId = "attachmentList" } = {}) {
    this.button = document.getElementById(buttonId);
    this.input = document.getElementById(inputId);
    this.list = document.getElementById(listId);
    this.files = [];
    if (!this.button || !this.input) return;
    this.button.addEventListener("click", () => this.input.click());
    this.input.addEventListener("change", event => this.addFiles(event.target.files));
  }

  async addFiles(fileList) {
    for (const file of Array.from(fileList || [])) {
      const isText = TEXT_TYPES.has(file.type) || TEXT_EXTENSIONS.test(file.name);
      if (!isText) {
        this.notify(`${file.name}: only text/code files are supported currently.`);
        continue;
      }
      if (file.size > 250 * 1024) {
        this.notify(`${file.name}: file exceeds the 250 KB limit.`);
        continue;
      }
      try {
        const content = await file.text();
        this.files.push({ name: file.name, content });
        this.render();
      } catch {
        this.notify(`Could not read ${file.name}.`);
      }
    }
    this.input.value = "";
  }

  consumeContext() {
    if (!this.files.length) return "";
    const context = this.files.map(file =>
      `--- FILE: ${file.name} ---\n${file.content}\n--- END FILE ---`
    ).join("\n\n");
    this.files = [];
    this.render();
    return context;
  }

  render() {
    if (!this.list) return;
    this.list.replaceChildren();
    this.files.forEach((file, index) => {
      const chip = document.createElement("span");
      chip.className = "prumim-attachment-chip";
      const name = document.createElement("span");
      name.textContent = file.name;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "×";
      remove.setAttribute("aria-label", `Remove ${file.name}`);
      remove.addEventListener("click", () => {
        this.files.splice(index, 1);
        this.render();
      });
      chip.append(name, remove);
      this.list.appendChild(chip);
    });
  }

  notify(message) {
    window.dispatchEvent(new CustomEvent("prumim:notice", { detail: { message } }));
  }
}

export default PRUMIMUpload;
