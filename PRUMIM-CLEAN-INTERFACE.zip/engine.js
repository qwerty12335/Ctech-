/**
 * PRUMIM AI — AUTONOMOUS ENGINE
 * Coordinates planning, tool execution, verification and task history.
 * Keeps Groq/tool execution in agent.js; this module orchestrates it.
 */
import runAgent, { MODEL } from "./agent.js";

const MAX_TASK_HISTORY = 40;

class PRUMIMEngine {
  constructor() {
    this.activeTasks = new Map();
    this.history = [];
  }

  emit(onActivity, state, detail, extra = {}) {
    const event = {
      state,
      detail,
      timestamp: new Date().toISOString(),
      ...extra
    };
    try { onActivity?.(event); } catch (error) {
      console.error("PRUMIM engine activity callback failed:", error);
    }
    return event;
  }

  async run({ messages, apiKey, systemPrompt, onActivity, taskId }) {
    const id = taskId || `task_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    if (this.activeTasks.has(id)) throw new Error("This PRUMIM task is already running.");

    const task = {
      id,
      status: "running",
      startedAt: new Date().toISOString(),
      steps: [],
      model: MODEL
    };
    this.activeTasks.set(id, task);

    const forward = (event) => {
      task.steps.push(event);
      if (task.steps.length > 100) task.steps.shift();
      this.emit(onActivity, event.state || "thinking", event.detail || "Working", {
        ...event,
        taskId: id
      });
    };

    try {
      this.emit(onActivity, "planning", "PRUMIM is preparing the task", { phase: "engine-start", taskId: id });
      const result = await runAgent({ messages, apiKey, systemPrompt, onActivity: forward });
      task.status = result.success ? "completed" : "incomplete";
      task.finishedAt = new Date().toISOString();
      task.activities = result.activities || [];
      this.history.unshift(task);
      this.history = this.history.slice(0, MAX_TASK_HISTORY);
      this.emit(onActivity, result.success ? "completed" : "error", result.success ? "Task completed and response verified" : "Task ended before completion", {
        phase: "engine-finish", taskId: id, success: !!result.success
      });
      return { ...result, task: { id, status: task.status, steps: task.steps.length } };
    } catch (error) {
      task.status = "failed";
      task.error = error.message;
      task.finishedAt = new Date().toISOString();
      this.history.unshift(task);
      this.history = this.history.slice(0, MAX_TASK_HISTORY);
      this.emit(onActivity, "error", error.message, { phase: "engine-error", taskId: id });
      throw error;
    } finally {
      this.activeTasks.delete(id);
    }
  }

  getStatus() {
    return {
      active: [...this.activeTasks.values()].map(({ id, status, startedAt, steps }) => ({ id, status, startedAt, stepCount: steps.length })),
      history: this.history.map(({ id, status, startedAt, finishedAt, model }) => ({ id, status, startedAt, finishedAt, model }))
    };
  }
}

const engine = new PRUMIMEngine();
export { PRUMIMEngine, engine };
export default engine;
